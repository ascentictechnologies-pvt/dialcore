var n={production:!0,apiUrl:"REPLACE_ME_API_URL"};export{n as a};
